# Version 0.1 does not enable code shrinking.
