package com.soroush.tarjomeh

import android.Manifest
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Clear
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private val AppNavy = Color(0xFF0B1324)
private val Panel = Color(0xFF171F34)
private val PanelLight = Color(0xFF1C2740)
private val PanelBorder = Color(0xFF253451)
private val Accent = Color(0xFF5B83FF)
private val Purple = Color(0xFF805AE7)
private val MainText = Color(0xFFF1F4FF)
private val MutedText = Color(0xFF96A9D4)
private val DimText = Color(0xFF64789F)

private data class TranslationEntry(
    val id: Long,
    val source: String,
    val target: String,
    val input: String,
    val output: String,
    val timestamp: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 19, 36)
        window.navigationBarColor = android.graphics.Color.rgb(11, 19, 36)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = 0
        setContent { TranslatorTheme { TranslatorApp() } }
    }
}

@Composable
private fun TranslatorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Purple,
            background = AppNavy,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = MainText,
            onSurface = MainText
        ),
        content = content
    )
}

@Composable
private fun TranslatorApp() {
    val context = LocalContext.current
    val preferences = remember {
        context.getSharedPreferences("tarjomeh_store", Context.MODE_PRIVATE)
    }
    val recents = remember { mutableStateListOf<TranslationEntry>() }
    val favorites = remember { mutableStateListOf<TranslationEntry>() }
    var sourceCode by remember { mutableStateOf(TranslateLanguage.PERSIAN) }
    var targetCode by remember { mutableStateOf(TranslateLanguage.ENGLISH) }
    var input by remember { mutableStateOf("") }
    var output by remember { mutableStateOf("") }
    var page by remember { mutableStateOf("home") }
    var translating by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }
    var currentEntry by remember { mutableStateOf<TranslationEntry?>(null) }
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val translator = remember(sourceCode, targetCode) {
        Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(sourceCode)
                .setTargetLanguage(targetCode)
                .build()
        )
    }
    DisposableEffect(translator) {
        onDispose { translator.close() }
    }

    LaunchedEffect(Unit) {
        recents.addAll(decodeEntries(preferences.getString("recent_entries", "[]")))
        favorites.addAll(decodeEntries(preferences.getString("favorite_entries", "[]")))

        // Prepare both directions early while internet is available. ML Kit keeps
        // downloaded models on-device, but its API does not support bundling them
        // directly inside this APK.
        statusMessage = "در حال آماده‌سازی مدل‌های فارسی و انگلیسی…"
        val persianToEnglish = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.PERSIAN)
                .setTargetLanguage(TranslateLanguage.ENGLISH)
                .build()
        )
        val englishToPersian = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.PERSIAN)
                .build()
        )
        var remainingModels = 2
        var anyModelFailed = false
        fun modelFinished() {
            remainingModels -= 1
            if (remainingModels == 0) {
                statusMessage = if (anyModelFailed) {
                    "آماده‌سازی کامل نشد؛ برای استفادهٔ آفلاین، هر دو مدل را با اینترنت دانلود کن."
                } else {
                    "مدل‌های فارسی و انگلیسی آماده‌اند؛ ترجمهٔ متن آفلاین قابل استفاده است."
                }
            }
        }
        val conditions = DownloadConditions.Builder().build()
        persianToEnglish.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { persianToEnglish.close(); modelFinished() }
            .addOnFailureListener { anyModelFailed = true; persianToEnglish.close(); modelFinished() }
        englishToPersian.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { englishToPersian.close(); modelFinished() }
            .addOnFailureListener { anyModelFailed = true; englishToPersian.close(); modelFinished() }
    }

    fun persistEntries() {
        preferences.edit()
            .putString("recent_entries", encodeEntries(recents))
            .putString("favorite_entries", encodeEntries(favorites))
            .apply()
    }

    fun addHistoryEntry(original: String, translated: String) {
        val now = System.currentTimeMillis()
        val entry = TranslationEntry(
            id = now,
            source = sourceCode,
            target = targetCode,
            input = original,
            output = translated,
            timestamp = now
        )
        recents.removeAll { it.input == original && it.source == sourceCode && it.target == targetCode }
        recents.add(0, entry)
        while (recents.size > 60) recents.removeAt(recents.lastIndex)
        currentEntry = entry
        persistEntries()
    }

    fun translateNow(text: String, onDone: (String) -> Unit = {}) {
        val clean = text.trim().take(5000)
        if (clean.isBlank()) {
            statusMessage = "اول متن موردنظر را وارد کن."
            return
        }
        translating = true
        statusMessage = "در حال آماده‌سازی مدل ترجمه…"
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                statusMessage = "در حال ترجمه…"
                translator.translate(clean)
                    .addOnSuccessListener { translated ->
                        output = translated
                        input = clean
                        translating = false
                        statusMessage = ""
                        addHistoryEntry(clean, translated)
                        onDone(translated)
                    }
                    .addOnFailureListener { error ->
                        translating = false
                        statusMessage = "ترجمه انجام نشد. اینترنت و فضای ذخیره‌سازی را بررسی کن."
                        onDone("")
                    }
            }
            .addOnFailureListener {
                translating = false
                statusMessage = "دانلود مدل ترجمه ناموفق بود؛ اتصال اینترنت را بررسی کن."
                onDone("")
            }
    }

    fun downloadCurrentModel() {
        statusMessage = "در حال بررسی مدل زبان‌ها…"
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener { statusMessage = "مدل این جهت ترجمه آماده است." }
            .addOnFailureListener { statusMessage = "دانلود مدل ناموفق بود. اتصال اینترنت را بررسی کن." }
    }

    fun updateSource(selected: String) {
        if (selected == targetCode) {
            val previous = sourceCode
            sourceCode = targetCode
            targetCode = previous
        } else {
            sourceCode = selected
        }
        output = ""
        currentEntry = null
        statusMessage = ""
    }

    fun updateTarget(selected: String) {
        if (selected == sourceCode) {
            val previous = targetCode
            targetCode = sourceCode
            sourceCode = previous
        } else {
            targetCode = selected
        }
        output = ""
        currentEntry = null
        statusMessage = ""
    }

    fun swapLanguages() {
        val oldSource = sourceCode
        sourceCode = targetCode
        targetCode = oldSource
        input = output.ifBlank { input }
        output = ""
        currentEntry = null
        statusMessage = ""
    }

    fun toggleFavorite(entry: TranslationEntry) {
        val existing = favorites.indexOfFirst { it.id == entry.id || (it.input == entry.input && it.output == entry.output && it.source == entry.source && it.target == entry.target) }
        if (existing >= 0) favorites.removeAt(existing) else favorites.add(0, entry)
        persistEntries()
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) {
                input = spoken.take(5000)
                output = ""
                statusMessage = ""
            }
        }
    }
    val microphonePermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val locale = if (sourceCode == TranslateLanguage.PERSIAN) "fa-IR" else "en-US"
            val speechIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, locale)
                putExtra(RecognizerIntent.EXTRA_PROMPT, if (sourceCode == TranslateLanguage.PERSIAN) "فارسی صحبت کن" else "Speak American English")
            }
            try {
                speechLauncher.launch(speechIntent)
            } catch (_: Exception) {
                statusMessage = "سرویس تشخیص گفتار روی این دستگاه در دسترس نیست."
            }
        } else {
            statusMessage = "برای ورود صوتی باید مجوز میکروفون را بدهی."
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        if (bitmap != null) {
            statusMessage = "در حال خواندن متن تصویر…"
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { visionText ->
                    recognizer.close()
                    if (visionText.text.isNotBlank()) {
                        input = visionText.text.take(5000)
                        output = ""
                        statusMessage = if (sourceCode == TranslateLanguage.PERSIAN) {
                            "متن استخراج شد. در نسخه ۰.۱، تشخیص متن تصویر برای حروف لاتین مناسب‌تر است."
                        } else "متن استخراج شد؛ برای ترجمه دکمه ترجمه را بزن."
                    } else {
                        statusMessage = "متنی پیدا نشد. نور و وضوح تصویر را بهتر کن."
                    }
                }
                .addOnFailureListener {
                    recognizer.close()
                    statusMessage = "خواندن تصویر ناموفق بود."
                }
        }
    }
    val textFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                val fileText = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    } catch (_: Exception) { "" }
                }
                if (fileText.isBlank()) {
                    statusMessage = "فایل خالی یا غیرقابل‌خواندن است؛ نسخه ۰.۱ از فایل متنی TXT پشتیبانی می‌کند."
                } else {
                    input = fileText.take(5000)
                    output = ""
                    statusMessage = if (fileText.length > 5000) "فقط ۵۰۰۰ نویسهٔ اول فایل بارگذاری شد." else "فایل بارگذاری شد."
                }
            }
        }
    }

    val showBottomBar = page in setOf("home", "history", "favorites", "more")
    androidx.compose.material3.Scaffold(
        containerColor = AppNavy,
        bottomBar = {
            if (showBottomBar) {
                BottomNavigationBar(page = page, onNavigate = { page = it })
            }
        }
    ) { insets ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(insets)
                .background(AppNavy)
        ) {
            when (page) {
                "home" -> HomeScreen(
                    sourceCode = sourceCode,
                    targetCode = targetCode,
                    input = input,
                    output = output,
                    translating = translating,
                    statusMessage = statusMessage,
                    recent = recents,
                    currentEntry = currentEntry,
                    isCurrentFavorite = currentEntry?.let { entry -> favorites.any { it.id == entry.id || (it.input == entry.input && it.output == entry.output) } } == true,
                    onInputChange = { input = it.take(5000); output = ""; currentEntry = null; statusMessage = "" },
                    onSourceSelected = ::updateSource,
                    onTargetSelected = ::updateTarget,
                    onSwap = ::swapLanguages,
                    onTranslate = { translateNow(input) },
                    onSettings = { page = "settings" },
                    onMic = { microphonePermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    onCamera = { try { cameraLauncher.launch(null) } catch (_: Exception) { statusMessage = "دوربین در دسترس نیست." } },
                    onConversation = { page = "conversation" },
                    onFile = { textFileLauncher.launch("text/plain") },
                    onCopyInput = { if (input.isNotBlank()) clipboard.setText(AnnotatedString(input)) },
                    onClearInput = { input = ""; output = ""; currentEntry = null; statusMessage = "" },
                    onCopyOutput = { if (output.isNotBlank()) clipboard.setText(AnnotatedString(output)) },
                    onToggleFavorite = { currentEntry?.let(::toggleFavorite) },
                    onOpenHistory = { page = "history" },
                    onOpenEntry = { entry ->
                        sourceCode = entry.source
                        targetCode = entry.target
                        input = entry.input
                        output = entry.output
                        currentEntry = entry
                        statusMessage = ""
                        page = "home"
                    }
                )
                "history" -> EntryListScreen(
                    title = "تاریخچه",
                    entries = recents,
                    emptyText = "هنوز ترجمه‌ای ثبت نشده است",
                    isFavorites = false,
                    onBack = { page = "home" },
                    onOpen = { entry ->
                        sourceCode = entry.source; targetCode = entry.target; input = entry.input; output = entry.output
                        currentEntry = entry; page = "home"; statusMessage = ""
                    },
                    onToggleFavorite = ::toggleFavorite,
                    favorites = favorites,
                    onDelete = { entry -> recents.removeAll { it.id == entry.id }; persistEntries() }
                )
                "favorites" -> EntryListScreen(
                    title = "علاقه‌مندی‌ها",
                    entries = favorites,
                    emptyText = "هنوز ترجمه‌ای به علاقه‌مندی‌ها اضافه نکرده‌ای",
                    isFavorites = true,
                    onBack = { page = "home" },
                    onOpen = { entry ->
                        sourceCode = entry.source; targetCode = entry.target; input = entry.input; output = entry.output
                        currentEntry = entry; page = "home"; statusMessage = ""
                    },
                    onToggleFavorite = ::toggleFavorite,
                    favorites = favorites,
                    onDelete = { entry -> favorites.removeAll { it.id == entry.id }; persistEntries() }
                )
                "more" -> MoreScreen(
                    onSettings = { page = "settings" },
                    onConversation = { page = "conversation" },
                    onAbout = { page = "about" }
                )
                "settings" -> SettingsScreen(
                    statusMessage = statusMessage,
                    onBack = { page = "home" },
                    onDownloadModel = ::downloadCurrentModel,
                    onClearHistory = {
                        recents.clear()
                        persistEntries()
                        statusMessage = "تاریخچه پاک شد."
                    }
                )
                "conversation" -> ConversationScreen(
                    sourceCode = sourceCode,
                    targetCode = targetCode,
                    onBack = { page = "home" },
                    onSwap = ::swapLanguages,
                    translate = { text, done -> translateNow(text, done) }
                )
                else -> AboutScreen(onBack = { page = "more" })
            }
        }
    }
}

@Composable
private fun HomeScreen(
    sourceCode: String,
    targetCode: String,
    input: String,
    output: String,
    translating: Boolean,
    statusMessage: String,
    recent: List<TranslationEntry>,
    currentEntry: TranslationEntry?,
    isCurrentFavorite: Boolean,
    onInputChange: (String) -> Unit,
    onSourceSelected: (String) -> Unit,
    onTargetSelected: (String) -> Unit,
    onSwap: () -> Unit,
    onTranslate: () -> Unit,
    onSettings: () -> Unit,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onConversation: () -> Unit,
    onFile: () -> Unit,
    onCopyInput: () -> Unit,
    onClearInput: () -> Unit,
    onCopyOutput: () -> Unit,
    onToggleFavorite: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenEntry: (TranslationEntry) -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)
            .padding(top = 10.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Image(painterResource(R.drawable.app_logo), contentDescription = "لوگوی مترجم", modifier = Modifier.size(62.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("مترجم", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("سریع، دقیق، همیشه در دسترس", color = MutedText, fontSize = 13.sp)
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Outlined.Settings, contentDescription = "تنظیمات", tint = MutedText, modifier = Modifier.size(27.dp))
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            LanguageSelector(
                code = sourceCode,
                modifier = Modifier.weight(1f),
                onSelect = onSourceSelected
            )
            Surface(
                modifier = Modifier.size(54.dp).clip(CircleShape).clickable(onClick = onSwap),
                color = Panel,
                shape = CircleShape,
                border = BorderStroke(1.dp, PanelBorder)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.SwapHoriz, contentDescription = "جابه‌جایی زبان‌ها", tint = Accent, modifier = Modifier.size(28.dp))
                }
            }
            LanguageSelector(
                code = targetCode,
                modifier = Modifier.weight(1f),
                onSelect = onTargetSelected
            )
        }

        Column {
            Surface(
                color = Panel,
                shape = RoundedCornerShape(24.dp),
                border = BorderStroke(1.dp, PanelBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    BasicTextField(
                        value = input,
                        onValueChange = { if (it.length <= 5000) onInputChange(it) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 142.dp),
                        textStyle = TextStyle(
                            color = MainText,
                            fontSize = 17.sp,
                            lineHeight = 27.sp,
                            textAlign = if (sourceCode == TranslateLanguage.PERSIAN) TextAlign.End else TextAlign.Start
                        ),
                        cursorBrush = SolidColor(Accent),
                        decorationBox = { innerTextField ->
                            Box(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 18.dp)) {
                                if (input.isEmpty()) {
                                    Text(
                                        "متن مورد نظر خود را وارد کنید…",
                                        color = MutedText.copy(alpha = 0.86f),
                                        fontSize = 17.sp,
                                        textAlign = if (sourceCode == TranslateLanguage.PERSIAN) TextAlign.End else TextAlign.Start,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                    Row(
                        Modifier.fillMaxWidth().padding(start = 15.dp, end = 10.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${input.length}/5000", color = DimText, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = onCopyInput, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = "کپی متن", tint = MutedText, modifier = Modifier.size(22.dp))
                        }
                        IconButton(onClick = onClearInput, modifier = Modifier.size(38.dp)) {
                            Icon(Icons.Outlined.Clear, contentDescription = "پاک کردن متن", tint = MutedText, modifier = Modifier.size(24.dp))
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = onTranslate,
                enabled = !translating && input.isNotBlank(),
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent, disabledContainerColor = PanelLight),
                contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp)
            ) {
                if (translating) {
                    Text("در حال ترجمه…", color = MainText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                } else {
                    Icon(Icons.Outlined.Language, contentDescription = null, tint = Color.White, modifier = Modifier.size(21.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("ترجمه کن", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
            FeatureButton(Icons.Outlined.Mic, "ورود صوتی", Modifier.weight(1f), onMic)
            FeatureButton(Icons.Outlined.CameraAlt, "ترجمه با دوربین", Modifier.weight(1f), onCamera)
            FeatureButton(Icons.Outlined.ChatBubbleOutline, "مکالمه", Modifier.weight(1f), onConversation)
            FeatureButton(Icons.Outlined.Description, "ترجمه فایل", Modifier.weight(1f), onFile)
        }

        if (output.isNotBlank()) {
            Surface(
                color = Panel,
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.dp, PanelBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ترجمه", color = MutedText, fontSize = 14.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = onCopyOutput, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = "کپی ترجمه", tint = MutedText)
                        }
                        IconButton(onClick = onToggleFavorite, modifier = Modifier.size(36.dp)) {
                            Icon(
                                if (isCurrentFavorite) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = "افزودن به علاقه‌مندی‌ها",
                                tint = if (isCurrentFavorite) Accent else MutedText
                            )
                        }
                    }
                    Text(
                        output,
                        color = MainText,
                        fontSize = 18.sp,
                        lineHeight = 29.sp,
                        textAlign = if (targetCode == TranslateLanguage.PERSIAN) TextAlign.End else TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        } else {
            Column(
                Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 0.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Image(
                    painterResource(R.drawable.app_logo),
                    contentDescription = null,
                    modifier = Modifier.size(112.dp)
                )
                Text("زبان‌ها را به هم نزدیک‌تر کنیم", color = Color(0xFFD9E2FF), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                Text("متن را وارد کن یا از امکانات دیگر استفاده کن.", color = MutedText, fontSize = 13.sp, textAlign = TextAlign.Center)
            }
        }

        Surface(
            color = Panel,
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(1.dp, PanelBorder),
            modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenHistory)
        ) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.History, contentDescription = null, tint = MutedText, modifier = Modifier.size(23.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("ترجمه‌های اخیر", color = MainText, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Icon(Icons.Outlined.ChevronRight, contentDescription = "نمایش تاریخچه", tint = MutedText)
                }
                val latest = recent.firstOrNull()
                if (latest != null) {
                    Text(latest.input, color = MutedText, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(latest.output, color = MainText, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                } else {
                    Text("ترجمه‌های ذخیره‌شده اینجا نمایش داده می‌شوند.", color = MutedText, fontSize = 13.sp)
                }
            }
        }

        if (statusMessage.isNotBlank()) {
            Text(statusMessage, color = if (statusMessage.contains("ناموفق") || statusMessage.contains("نشد")) Color(0xFFFFB4AB) else MutedText, fontSize = 12.sp, lineHeight = 18.sp)
        }
        Text("نسخه ۰.۱", color = DimText, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun LanguageSelector(code: String, modifier: Modifier = Modifier, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box(modifier) {
        Surface(
            color = Panel,
            shape = RoundedCornerShape(24.dp),
            border = BorderStroke(1.dp, PanelBorder),
            modifier = Modifier.fillMaxWidth().height(64.dp).clickable { expanded = true }
        ) {
            Row(
                Modifier.padding(horizontal = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(if (code == TranslateLanguage.PERSIAN) "🇮🇷" else "🇺🇸", fontSize = 25.sp)
                Text(
                    if (code == TranslateLanguage.PERSIAN) "فارسی" else "انگلیسی",
                    color = MainText,
                    fontSize = if (code == TranslateLanguage.PERSIAN) 16.sp else 12.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Text("⌄", color = MutedText, fontSize = 24.sp)
            }
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Panel)
        ) {
            DropdownMenuItem(
                text = { Text("🇮🇷  فارسی", color = MainText) },
                onClick = { expanded = false; onSelect(TranslateLanguage.PERSIAN) }
            )
            DropdownMenuItem(
                text = { Text("🇺🇸  انگلیسی (آمریکایی)", color = MainText) },
                onClick = { expanded = false; onSelect(TranslateLanguage.ENGLISH) }
            )
        }
    }
}

@Composable
private fun FeatureButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier = modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Surface(
            color = Panel,
            shape = RoundedCornerShape(21.dp),
            border = BorderStroke(1.dp, PanelBorder.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth().height(67.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = label, tint = Accent, modifier = Modifier.size(31.dp))
            }
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = MutedText, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2, lineHeight = 14.sp)
    }
}

@Composable
private fun BottomNavigationBar(page: String, onNavigate: (String) -> Unit) {
    NavigationBar(containerColor = AppNavy, contentColor = MutedText, tonalElevation = 0.dp) {
        val items = listOf(
            Triple("home", "خانه", Icons.Outlined.Home),
            Triple("history", "تاریخچه", Icons.Outlined.History),
            Triple("favorites", "علاقه‌مندی‌ها", Icons.Outlined.StarBorder),
            Triple("more", "بیشتر", Icons.Outlined.PersonOutline)
        )
        items.forEach { (route, label, icon) ->
            NavigationBarItem(
                selected = page == route,
                onClick = { onNavigate(route) },
                icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(23.dp)) },
                label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Accent,
                    selectedTextColor = Accent,
                    unselectedIconColor = MutedText,
                    unselectedTextColor = MutedText,
                    indicatorColor = Panel
                )
            )
        }
    }
}

@Composable
private fun PageHeader(title: String, onBack: () -> Unit, trailing: @Composable (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Outlined.ArrowBack, contentDescription = "بازگشت", tint = MutedText)
        }
        Text(title, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        if (trailing != null) trailing()
    }
}

@Composable
private fun EntryListScreen(
    title: String,
    entries: List<TranslationEntry>,
    emptyText: String,
    isFavorites: Boolean,
    onBack: () -> Unit,
    onOpen: (TranslationEntry) -> Unit,
    onToggleFavorite: (TranslationEntry) -> Unit,
    favorites: List<TranslationEntry>,
    onDelete: (TranslationEntry) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        PageHeader(title, onBack)
        if (entries.isEmpty()) {
            Column(
                Modifier.fillMaxSize().padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(if (isFavorites) Icons.Outlined.StarBorder else Icons.Outlined.History, contentDescription = null, tint = DimText, modifier = Modifier.size(54.dp))
                Spacer(Modifier.height(12.dp))
                Text(emptyText, color = MutedText, fontSize = 15.sp, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(entries, key = { it.id }) { entry ->
                    EntryCard(
                        entry = entry,
                        isFavorite = favorites.any { it.id == entry.id || (it.input == entry.input && it.output == entry.output && it.source == entry.source && it.target == entry.target) },
                        onOpen = { onOpen(entry) },
                        onToggleFavorite = { onToggleFavorite(entry) },
                        onDelete = { onDelete(entry) }
                    )
                }
            }
        }
    }
}

@Composable
private fun EntryCard(
    entry: TranslationEntry,
    isFavorite: Boolean,
    onOpen: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen)
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(languageName(entry.source) + " ← " + languageName(entry.target), color = MutedText, fontSize = 11.sp, modifier = Modifier.weight(1f))
                Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(entry.timestamp)), color = DimText, fontSize = 10.sp)
            }
            Text(entry.input, color = MainText, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(entry.output, color = MutedText, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                IconButton(onClick = onToggleFavorite, modifier = Modifier.size(36.dp)) {
                    Icon(if (isFavorite) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder, contentDescription = "علاقه‌مندی", tint = if (isFavorite) Accent else MutedText)
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "حذف", tint = MutedText)
                }
            }
        }
    }
}

@Composable
private fun MoreScreen(onSettings: () -> Unit, onConversation: () -> Unit, onAbout: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("بیشتر", color = MainText, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("مترجم · نسخه ۰.۱", color = MutedText, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        MoreRow(Icons.Outlined.Settings, "تنظیمات", "مدیریت مدل ترجمه و داده‌ها", onSettings)
        MoreRow(Icons.Outlined.ChatBubbleOutline, "حالت مکالمه", "ترجمه رفت‌وبرگشتی بین دو زبان", onConversation)
        MoreRow(Icons.Outlined.Info, "درباره برنامه", "نسخه و توضیحات مترجم", onAbout)
        Spacer(Modifier.height(8.dp))
        Text("در نسخهٔ ۰.۱ فقط فارسی ایران و انگلیسی آمریکایی در دسترس است.", color = MutedText, fontSize = 13.sp, lineHeight = 21.sp)
    }
}

@Composable
private fun MoreRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Surface(
        color = Panel,
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.dp, PanelBorder),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(27.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = MainText, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Text(subtitle, color = MutedText, fontSize = 12.sp)
            }
            Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = MutedText)
        }
    }
}

@Composable
private fun SettingsScreen(statusMessage: String, onBack: () -> Unit, onDownloadModel: () -> Unit, onClearHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader("تنظیمات", onBack)
        Column(Modifier.padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text("ترجمه", color = MutedText, fontSize = 13.sp)
            MoreRow(Icons.Outlined.Download, "آماده‌سازی مدل ترجمه", "دانلود هر دو جهت ترجمه برای استفادهٔ آفلاین", onDownloadModel)
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, PanelBorder), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Icon(Icons.Outlined.CheckCircleOutline, contentDescription = null, tint = Accent, modifier = Modifier.size(25.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("ترجمه روی دستگاه", color = MainText, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(4.dp))
                        Text("مدل‌های ترجمه در اولین اجرا با اینترنت دانلود می‌شوند. پس از تکمیل دانلود هر دو مدل، ترجمهٔ متن روی دستگاه انجام می‌شود و به اینترنت نیاز ندارد. خود مدل‌ها داخل فایل APK بسته‌بندی نشده‌اند.", color = MutedText, fontSize = 12.sp, lineHeight = 19.sp)
                    }
                }
            }
            if (statusMessage.isNotBlank()) Text(statusMessage, color = MutedText, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            Text("داده‌ها", color = MutedText, fontSize = 13.sp)
            MoreRow(Icons.Outlined.DeleteOutline, "پاک کردن تاریخچه", "موارد تاریخچه حذف می‌شوند؛ علاقه‌مندی‌ها باقی می‌مانند", onClearHistory)
            Spacer(Modifier.height(8.dp))
            Text("مترجم · نسخه ۰.۱.۱", color = DimText, fontSize = 12.sp)
            Text("موتور ترجمه: Google ML Kit Translation", color = DimText, fontSize = 11.sp)
        }
    }
}

@Composable
private fun AboutScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        PageHeader("درباره برنامه", onBack)
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(13.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.app_logo), contentDescription = "لوگوی مترجم", modifier = Modifier.size(100.dp))
            Text("مترجم", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("نسخه ۰.۱", color = MutedText, fontSize = 14.sp)
            Text(
                "مترجم فارسی و انگلیسی با پشتیبانی از ورودی صوتی، استخراج متن از دوربین، وارد کردن فایل متنی، تاریخچه و علاقه‌مندی‌ها.",
                color = MutedText, textAlign = TextAlign.Center, fontSize = 14.sp, lineHeight = 23.sp
            )
            Text("ترجمه با Google ML Kit انجام می‌شود. برای ترجمهٔ اولیه باید مدل زبان دانلود شود.", color = DimText, textAlign = TextAlign.Center, fontSize = 12.sp, lineHeight = 20.sp)
        }
    }
}

private data class ChatLine(val text: String, val isOriginal: Boolean)

@Composable
private fun ConversationScreen(
    sourceCode: String,
    targetCode: String,
    onBack: () -> Unit,
    onSwap: () -> Unit,
    translate: (String, (String) -> Unit) -> Unit
) {
    var message by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf<ChatLine>() }
    Column(Modifier.fillMaxSize()) {
        PageHeader("مکالمه", onBack, trailing = {
            IconButton(onClick = onSwap) {
                Icon(Icons.Outlined.SwapHoriz, contentDescription = "جابه‌جایی زبان‌ها", tint = Accent)
            }
        })
        Text("${languageName(sourceCode)}  ↔  ${languageName(targetCode)}", color = MutedText, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 22.dp))
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            if (lines.isEmpty()) {
                item {
                    Text("پیام را وارد کن؛ ترجمه در همین صفحه نمایش داده می‌شود.", color = MutedText, fontSize = 14.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 18.dp))
                }
            }
            items(lines) { line ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.isOriginal) Arrangement.End else Arrangement.Start) {
                    Surface(
                        color = if (line.isOriginal) PanelLight else Panel,
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(1.dp, PanelBorder),
                        modifier = Modifier.fillMaxWidth(0.88f)
                    ) {
                        Text(line.text, color = MainText, fontSize = 15.sp, lineHeight = 23.sp, modifier = Modifier.padding(13.dp))
                    }
                }
            }
        }
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Surface(color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, PanelBorder), modifier = Modifier.fillMaxWidth()) {
                BasicTextField(
                    value = message,
                    onValueChange = { message = it.take(5000) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp).padding(15.dp),
                    textStyle = TextStyle(color = MainText, fontSize = 16.sp, lineHeight = 24.sp),
                    cursorBrush = SolidColor(Accent),
                    decorationBox = { inner ->
                        Box {
                            if (message.isBlank()) Text("متن پیام…", color = MutedText, fontSize = 15.sp)
                            inner()
                        }
                    }
                )
            }
            Button(
                onClick = {
                    val original = message.trim()
                    if (original.isNotBlank() && !busy) {
                        lines.add(ChatLine(original, true))
                        message = ""
                        busy = true
                        error = ""
                        translate(original) { translated ->
                            if (translated.isNotBlank()) {
                                lines.add(ChatLine(translated, false))
                            } else {
                                error = "ترجمه انجام نشد؛ اتصال اینترنت را بررسی کن."
                            }
                            busy = false
                        }
                    }
                },
                enabled = message.isNotBlank() && !busy,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Text(if (busy) "در حال ترجمه…" else "ارسال و ترجمه", color = Color.White) }
            if (error.isNotBlank()) Text(error, color = MutedText, fontSize = 12.sp)
        }
    }
}

private fun languageName(code: String): String =
    if (code == TranslateLanguage.PERSIAN) "فارسی" else "انگلیسی آمریکایی"

private fun encodeEntries(entries: List<TranslationEntry>): String {
    val array = JSONArray()
    entries.forEach { entry ->
        array.put(
            JSONObject()
                .put("id", entry.id)
                .put("source", entry.source)
                .put("target", entry.target)
                .put("input", entry.input)
                .put("output", entry.output)
                .put("timestamp", entry.timestamp)
        )
    }
    return array.toString()
}

private fun decodeEntries(raw: String?): List<TranslationEntry> {
    if (raw.isNullOrBlank()) return emptyList()
    return try {
        val array = JSONArray(raw)
        buildList {
            for (index in 0 until array.length()) {
                val obj = array.optJSONObject(index) ?: continue
                add(
                    TranslationEntry(
                        id = obj.optLong("id", System.currentTimeMillis() + index),
                        source = obj.optString("source", TranslateLanguage.PERSIAN),
                        target = obj.optString("target", TranslateLanguage.ENGLISH),
                        input = obj.optString("input", ""),
                        output = obj.optString("output", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        }
    } catch (_: Exception) {
        emptyList()
    }
}
